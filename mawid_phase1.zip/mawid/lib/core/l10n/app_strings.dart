import 'package:flutter/widgets.dart';

/// Lightweight translations (ar / fr / en). Add keys here.
class AppStrings {
  final String code;
  AppStrings(this.code);

  static AppStrings of(BuildContext c) =>
      AppStrings(Localizations.localeOf(c).languageCode);

  static const _t = <String, Map<String, String>>{
    'app_name': {'ar': 'موعد', 'fr': 'Mawid', 'en': 'Mawid'},
    'skip': {'ar': 'تخطي', 'fr': 'Passer', 'en': 'Skip'},
    'next': {'ar': 'التالي', 'fr': 'Suivant', 'en': 'Next'},
    'start': {'ar': 'ابدأ', 'fr': 'Commencer', 'en': 'Get started'},
    'ob1_title': {'ar': 'احجز في 3 نقرات', 'fr': 'Réservez en 3 clics', 'en': 'Book in 3 taps'},
    'ob1_body': {'ar': 'حلاق، عيادة، كراج وأكثر قرب منك', 'fr': 'Coiffeur, clinique, garage et plus près de vous', 'en': 'Barbers, clinics, garages and more near you'},
    'ob2_title': {'ar': 'بلا مكالمات', 'fr': 'Sans appels', 'en': 'No more calls'},
    'ob2_body': {'ar': 'شوف الأوقات المتاحة وأكد فوراً', 'fr': 'Voyez les créneaux et confirmez', 'en': 'See free slots and confirm instantly'},
    'ob3_title': {'ar': 'تذكير قبل الموعد', 'fr': 'Rappels avant le RDV', 'en': 'Reminders before you go'},
    'ob3_body': {'ar': 'إشعار قبل 24 ساعة وقبل ساعة', 'fr': 'Notification 24h et 1h avant', 'en': 'Notified 24h and 1h before'},
    'phone': {'ar': 'رقم الهاتف', 'fr': 'Numéro de téléphone', 'en': 'Phone number'},
    'send_code': {'ar': 'إرسال الرمز', 'fr': 'Envoyer le code', 'en': 'Send code'},
    'otp_title': {'ar': 'أدخل رمز التحقق', 'fr': 'Entrez le code', 'en': 'Enter the code'},
    'verify': {'ar': 'تأكيد', 'fr': 'Vérifier', 'en': 'Verify'},
    'guest': {'ar': 'تصفح كزائر', 'fr': 'Continuer en invité', 'en': 'Browse as guest'},
    'invalid_phone': {'ar': 'رقم غير صالح', 'fr': 'Numéro invalide', 'en': 'Invalid number'},
    'error': {'ar': 'حدث خطأ، حاول مجدداً', 'fr': 'Erreur, réessayez', 'en': 'Something went wrong, retry'},
    'search_hint': {'ar': 'ابحث عن خدمة...', 'fr': 'Rechercher un service...', 'en': 'Search a service...'},
    'cat_barber': {'ar': 'حلاق', 'fr': 'Coiffeur', 'en': 'Barber'},
    'cat_salon': {'ar': 'صالون', 'fr': 'Salon', 'en': 'Salon'},
    'cat_clinic': {'ar': 'عيادة', 'fr': 'Clinique', 'en': 'Clinic'},
    'cat_dentist': {'ar': 'طبيب أسنان', 'fr': 'Dentiste', 'en': 'Dentist'},
    'cat_garage': {'ar': 'كراج', 'fr': 'Garage', 'en': 'Garage'},
    'cat_hammam': {'ar': 'حمام', 'fr': 'Hammam', 'en': 'Hammam'},
    'cat_gym': {'ar': 'نادي رياضي', 'fr': 'Salle de sport', 'en': 'Gym'},
    'cat_cleaning': {'ar': 'تنظيف', 'fr': 'Nettoyage', 'en': 'Cleaning'},
    'cat_plumber': {'ar': 'سباك', 'fr': 'Plombier', 'en': 'Plumber'},
    'cat_electrician': {'ar': 'كهربائي', 'fr': 'Électricien', 'en': 'Electrician'},
    'cat_tutor': {'ar': 'دروس خصوصية', 'fr': 'Cours', 'en': 'Tutor'},
  };

  String tr(String key) => _t[key]?[code] ?? _t[key]?['en'] ?? key;
}

extension Tr on BuildContext {
  String tr(String key) => AppStrings.of(this).tr(key);
}
