import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../core/l10n/app_strings.dart';
import '../../../core/l10n/settings_providers.dart';

class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});
  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingState();
}

class _OnboardingState extends ConsumerState<OnboardingScreen> {
  final _page = PageController();
  int _i = 0;
  static const _icons = [
    Icons.touch_app,
    Icons.phone_disabled,
    Icons.notifications_active
  ];

  void _finish() {
    Hive.box('settings').put('onboarded', true);
    ref.read(onboardedProvider.notifier).state = true;
    context.go('/login');
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          Align(
            alignment: AlignmentDirectional.centerEnd,
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              for (final l in const ['ar', 'fr', 'en'])
                TextButton(
                  onPressed: () => ref.read(localeProvider.notifier).set(l),
                  child: Text(l.toUpperCase()),
                ),
              TextButton(onPressed: _finish, child: Text(context.tr('skip'))),
            ]),
          ),
          Expanded(
            child: PageView.builder(
              controller: _page,
              itemCount: 3,
              onPageChanged: (v) => setState(() => _i = v),
              itemBuilder: (_, n) => Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(_icons[n], size: 120, color: cs.primary),
                      const SizedBox(height: 32),
                      Text(context.tr('ob${n + 1}_title'),
                          style: Theme.of(context).textTheme.headlineMedium,
                          textAlign: TextAlign.center),
                      const SizedBox(height: 12),
                      Text(context.tr('ob${n + 1}_body'),
                          textAlign: TextAlign.center),
                    ]),
              ),
            ),
          ),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            for (var n = 0; n < 3; n++)
              AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.all(4),
                width: n == _i ? 24 : 8,
                height: 8,
                decoration: BoxDecoration(
                    color: n == _i ? cs.secondary : cs.outlineVariant,
                    borderRadius: BorderRadius.circular(4)),
              ),
          ]),
          Padding(
            padding: const EdgeInsets.all(24),
            child: FilledButton(
              onPressed: () => _i == 2
                  ? _finish()
                  : _page.nextPage(
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeOut),
              child: Text(context.tr(_i == 2 ? 'start' : 'next')),
            ),
          ),
        ]),
      ),
    );
  }
}
