# Mawid (موعد) — Phase 1, Batches 1–2

Appointment booking app for Morocco. Flutter + Riverpod + Firebase + OpenStreetMap.

## Setup
1. Install Flutter (3.22+). In this folder run:
   `flutter create . --org ma.mawid --project-name mawid`
   (generates android/ios folders without touching lib/ or pubspec.yaml)
2. `flutter pub get`
3. Create a Firebase project. Enable Authentication > Phone and Firestore.
4. `dart pub global activate flutterfire_cli && flutterfire configure`
5. Add SHA-1 and SHA-256 of your debug key in Firebase (needed for OTP).
   Get them: `cd android && ./gradlew signingReport`
6. Optional: add a test phone number + fixed code in Firebase to avoid SMS cost.
7. Deploy rules: `firebase deploy --only firestore:rules`
8. `flutter test` then `flutter run`

## Files
- lib/main.dart — app start, Hive, Firebase, theme, language
- lib/core/theme — Material 3 green/gold theme (light/dark)
- lib/core/l10n — ar/fr/en strings and saved settings (RTL automatic)
- lib/core/router — go_router routes
- lib/features/auth — onboarding, phone login, OTP, +212 normalization
- lib/features/home — temporary home with category grid
- lib/features/booking/domain — slot generator (tested)
- lib/features/booking/data — transaction-based booking (no double-booking)
- firestore.rules — starter security rules
- test/ — unit tests

## Next batches
3: search + filters + OSM map + business page. 4: booking screens, reminders
(Cloud Function), seed data (Casablanca, Rabat, Marrakech).
