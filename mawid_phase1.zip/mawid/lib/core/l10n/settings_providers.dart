import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';

Box _box() => Hive.box('settings');

class LocaleNotifier extends StateNotifier<Locale?> {
  LocaleNotifier() : super(_load());
  static Locale? _load() {
    final c = _box().get('lang') as String?;
    return c == null ? null : Locale(c);
  }

  void set(String code) {
    _box().put('lang', code);
    state = Locale(code);
  }
}

final localeProvider =
    StateNotifierProvider<LocaleNotifier, Locale?>((_) => LocaleNotifier());

class ThemeNotifier extends StateNotifier<ThemeMode> {
  ThemeNotifier()
      : super(ThemeMode.values[_box().get('theme', defaultValue: 0) as int]);
  void set(ThemeMode m) {
    _box().put('theme', m.index);
    state = m;
  }
}

final themeProvider =
    StateNotifierProvider<ThemeNotifier, ThemeMode>((_) => ThemeNotifier());

final onboardedProvider = StateProvider<bool>(
    (_) => _box().get('onboarded', defaultValue: false) as bool);
