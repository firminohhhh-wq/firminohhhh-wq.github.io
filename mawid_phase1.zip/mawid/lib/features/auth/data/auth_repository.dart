import 'package:firebase_auth/firebase_auth.dart';

class AuthRepository {
  final FirebaseAuth _auth;
  AuthRepository(this._auth);

  User? get currentUser => _auth.currentUser;

  /// Normalizes 06/07 local numbers to +212.
  static String? normalize(String input) {
    var d = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (d.startsWith('+212')) {
      d = d.substring(4);
    } else if (d.startsWith('00212')) {
      d = d.substring(5);
    } else if (d.startsWith('0')) {
      d = d.substring(1);
    }
    return RegExp(r'^[5-7]\d{8}$').hasMatch(d) ? '+212$d' : null;
  }

  Future<void> sendCode({
    required String phone,
    required void Function(String verificationId) onCodeSent,
    required void Function(String message) onError,
    required Future<void> Function(PhoneAuthCredential) onAutoVerified,
  }) {
    return _auth.verifyPhoneNumber(
      phoneNumber: phone,
      timeout: const Duration(seconds: 60),
      verificationCompleted: onAutoVerified,
      verificationFailed: (e) => onError(e.code),
      codeSent: (id, _) => onCodeSent(id),
      codeAutoRetrievalTimeout: (_) {},
    );
  }

  Future<UserCredential> confirm(String verificationId, String code) =>
      _auth.signInWithCredential(PhoneAuthProvider.credential(
          verificationId: verificationId, smsCode: code));

  Future<void> signOut() => _auth.signOut();
}
