import 'package:flutter_test/flutter_test.dart';
import 'package:mawid/features/auth/data/auth_repository.dart';

void main() {
  test('normalizes Moroccan numbers', () {
    expect(AuthRepository.normalize('0612345678'), '+212612345678');
    expect(AuthRepository.normalize('+212 6 12 34 56 78'), '+212612345678');
    expect(AuthRepository.normalize('00212712345678'), '+212712345678');
    expect(AuthRepository.normalize('12345'), isNull);
  });
}
