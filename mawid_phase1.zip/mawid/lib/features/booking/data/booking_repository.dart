import 'package:cloud_firestore/cloud_firestore.dart';

class SlotTakenException implements Exception {}

class BookingRepository {
  final FirebaseFirestore _db;
  BookingRepository(this._db);

  /// Creates a booking. One lock doc per 15-min cell makes double-booking
  /// impossible: the transaction fails if any cell is already locked.
  Future<String> createBooking({
    required String businessId,
    required String staffId,
    required String customerId,
    required List<String> serviceIds,
    required DateTime start,
    required Duration totalDuration,
    required num totalPrice,
    String? notes,
  }) async {
    final bookingRef = _db.collection('bookings').doc();
    final cells = <DocumentReference>[];
    for (var m = 0; m < totalDuration.inMinutes; m += 15) {
      final cellStart = start.add(Duration(minutes: m));
      final id = '${staffId}_${cellStart.millisecondsSinceEpoch}';
      cells.add(_db.collection('slotLocks').doc(id));
    }

    await _db.runTransaction((tx) async {
      for (final c in cells) {
        if ((await tx.get(c)).exists) throw SlotTakenException();
      }
      for (final c in cells) {
        tx.set(c, {'bookingId': bookingRef.id, 'businessId': businessId});
      }
      tx.set(bookingRef, {
        'businessId': businessId,
        'staffId': staffId,
        'customerId': customerId,
        'serviceIds': serviceIds,
        'start': Timestamp.fromDate(start),
        'end': Timestamp.fromDate(start.add(totalDuration)),
        'totalPrice': totalPrice,
        'notes': notes,
        'status': 'pending',
        'code': bookingRef.id.substring(0, 6).toUpperCase(),
        'createdAt': FieldValue.serverTimestamp(),
      });
    });
    return bookingRef.id;
  }
}
