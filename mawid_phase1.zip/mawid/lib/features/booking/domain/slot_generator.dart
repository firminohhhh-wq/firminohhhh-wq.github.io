/// A time range with a start and end.
class TimeRange {
  final DateTime start;
  final DateTime end;
  const TimeRange(this.start, this.end);

  bool overlaps(TimeRange o) => start.isBefore(o.end) && end.isAfter(o.start);
}

class SlotGenerator {
  /// Returns bookable start times for one day.
  static List<DateTime> freeSlots({
    required List<TimeRange> workingHours,
    required List<TimeRange> booked,
    required Duration duration,
    Duration buffer = Duration.zero,
    Duration step = const Duration(minutes: 15),
    required DateTime now,
  }) {
    final slots = <DateTime>[];
    final needed = duration + buffer;
    for (final window in workingHours) {
      var cursor = window.start;
      while (!cursor.add(duration).isAfter(window.end)) {
        final candidate = TimeRange(cursor, cursor.add(needed));
        final isFuture = cursor.isAfter(now);
        final clash = booked.any(candidate.overlaps);
        if (isFuture && !clash) slots.add(cursor);
        cursor = cursor.add(step);
      }
    }
    return slots;
  }
}
