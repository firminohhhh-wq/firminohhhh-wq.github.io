import 'package:flutter/material.dart';
import '../../../core/l10n/app_strings.dart';

/// Temporary home: search bar + category grid. Batch 3 adds real search,
/// filters, OSM map and business pages.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  static const _cats = <(String, IconData)>[
    ('cat_barber', Icons.content_cut),
    ('cat_salon', Icons.face_retouching_natural),
    ('cat_clinic', Icons.local_hospital),
    ('cat_dentist', Icons.medical_services),
    ('cat_garage', Icons.car_repair),
    ('cat_hammam', Icons.hot_tub),
    ('cat_gym', Icons.fitness_center),
    ('cat_cleaning', Icons.cleaning_services),
    ('cat_plumber', Icons.plumbing),
    ('cat_electrician', Icons.electrical_services),
    ('cat_tutor', Icons.school),
  ];

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('app_name'))),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          TextField(
            decoration: InputDecoration(
              hintText: context.tr('search_hint'),
              prefixIcon: const Icon(Icons.search),
              suffixIcon: const Icon(Icons.mic),
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: GridView.count(
              crossAxisCount: 3,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              children: [
                for (final c in _cats)
                  Card(
                    color: cs.primaryContainer,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () {},
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(c.$2, size: 34, color: cs.primary),
                            const SizedBox(height: 8),
                            Text(context.tr(c.$1),
                                textAlign: TextAlign.center),
                          ]),
                    ),
                  ),
              ],
            ),
          ),
        ]),
      ),
    );
  }
}
