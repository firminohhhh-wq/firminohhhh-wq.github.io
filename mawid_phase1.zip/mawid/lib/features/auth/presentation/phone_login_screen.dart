import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/l10n/app_strings.dart';
import '../data/auth_repository.dart';

class PhoneLoginScreen extends StatefulWidget {
  const PhoneLoginScreen({super.key});
  @override
  State<PhoneLoginScreen> createState() => _PhoneLoginScreenState();
}

class _PhoneLoginScreenState extends State<PhoneLoginScreen> {
  final _ctrl = TextEditingController();
  final _repo = AuthRepository(FirebaseAuth.instance);
  bool _loading = false;
  String? _error;

  Future<void> _send() async {
    final phone = AuthRepository.normalize(_ctrl.text);
    if (phone == null) {
      setState(() => _error = context.tr('invalid_phone'));
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    await _repo.sendCode(
      phone: phone,
      onCodeSent: (id) {
        if (!mounted) return;
        setState(() => _loading = false);
        context.push('/otp', extra: {'id': id, 'phone': phone});
      },
      onError: (_) {
        if (!mounted) return;
        setState(() {
          _loading = false;
          _error = context.tr('error');
        });
      },
      onAutoVerified: (cred) async {
        await FirebaseAuth.instance.signInWithCredential(cred);
        if (mounted) context.go('/home');
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SizedBox(height: 48),
            Text(context.tr('app_name'),
                style: Theme.of(context).textTheme.displaySmall),
            const SizedBox(height: 32),
            TextField(
              controller: _ctrl,
              keyboardType: TextInputType.phone,
              textDirection: TextDirection.ltr,
              decoration: InputDecoration(
                labelText: context.tr('phone'),
                prefixText: '+212  ',
                errorText: _error,
              ),
            ),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: _loading ? null : _send,
              child: _loading
                  ? const SizedBox(
                      height: 22,
                      width: 22,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : Text(context.tr('send_code')),
            ),
            const Spacer(),
            Center(
              child: TextButton(
                onPressed: () => context.go('/home'),
                child: Text(context.tr('guest')),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
