import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/l10n/app_strings.dart';
import '../data/auth_repository.dart';

class OtpScreen extends StatefulWidget {
  final String verificationId;
  final String phone;
  const OtpScreen(
      {super.key, required this.verificationId, required this.phone});
  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  final _ctrl = TextEditingController();
  final _repo = AuthRepository(FirebaseAuth.instance);
  bool _loading = false;
  String? _error;

  Future<void> _verify() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      await _repo.confirm(widget.verificationId, _ctrl.text.trim());
      if (mounted) context.go('/home');
    } on FirebaseAuthException {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = context.tr('error');
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(context.tr('otp_title'),
              style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          Text(widget.phone, textDirection: TextDirection.ltr),
          const SizedBox(height: 24),
          TextField(
            controller: _ctrl,
            keyboardType: TextInputType.number,
            maxLength: 6,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 28, letterSpacing: 8),
            decoration: InputDecoration(errorText: _error, counterText: ''),
          ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: _loading ? null : _verify,
            child: Text(context.tr('verify')),
          ),
        ]),
      ),
    );
  }
}
