import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../features/auth/presentation/onboarding_screen.dart';
import '../../features/auth/presentation/otp_screen.dart';
import '../../features/auth/presentation/phone_login_screen.dart';
import '../../features/home/presentation/home_screen.dart';
import '../l10n/settings_providers.dart';

final routerProvider = Provider<GoRouter>((ref) {
  final onboarded = ref.read(onboardedProvider);
  return GoRouter(
    initialLocation: onboarded ? '/login' : '/onboarding',
    routes: [
      GoRoute(path: '/onboarding', builder: (_, __) => const OnboardingScreen()),
      GoRoute(path: '/login', builder: (_, __) => const PhoneLoginScreen()),
      GoRoute(
        path: '/otp',
        builder: (_, s) {
          final m = s.extra as Map<String, String>;
          return OtpScreen(verificationId: m['id']!, phone: m['phone']!);
        },
      ),
      GoRoute(path: '/home', builder: (_, __) => const HomeScreen()),
    ],
    redirect: (_, state) {
      final loggedIn = FirebaseAuth.instance.currentUser != null;
      if (loggedIn && state.matchedLocation == '/login') return '/home';
      return null;
    },
  );
});
