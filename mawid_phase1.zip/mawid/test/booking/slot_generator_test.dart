import 'package:flutter_test/flutter_test.dart';
import 'package:mawid/features/booking/domain/slot_generator.dart';

void main() {
  final day = DateTime(2026, 11, 12);
  DateTime t(int h, [int m = 0]) => DateTime(day.year, day.month, day.day, h, m);
  final past = DateTime(2026, 11, 1);
  const half = Duration(minutes: 30);

  test('generates slots inside working hours', () {
    final s = SlotGenerator.freeSlots(
      workingHours: [TimeRange(t(9), t(11))],
      booked: [], duration: half, step: half, now: past);
    expect(s, [t(9), t(9, 30), t(10), t(10, 30)]);
  });

  test('excludes slots that overlap a booking', () {
    final s = SlotGenerator.freeSlots(
      workingHours: [TimeRange(t(9), t(11))],
      booked: [TimeRange(t(9, 30), t(10))],
      duration: half, step: half, now: past);
    expect(s, [t(9), t(10), t(10, 30)]);
  });

  test('buffer blocks the slot right before a booking', () {
    final s = SlotGenerator.freeSlots(
      workingHours: [TimeRange(t(9), t(11))],
      booked: [TimeRange(t(10), t(10, 30))],
      duration: half, buffer: const Duration(minutes: 15),
      step: half, now: past);
    expect(s.contains(t(9, 30)), false);
    expect(s.contains(t(9)), true);
  });

  test('hides past slots for today', () {
    final s = SlotGenerator.freeSlots(
      workingHours: [TimeRange(t(9), t(11))],
      booked: [], duration: half, step: half, now: t(10));
    expect(s, [t(10, 30)]);
  });

  test('service longer than window gives no slots', () {
    final s = SlotGenerator.freeSlots(
      workingHours: [TimeRange(t(9), t(9, 30))],
      booked: [], duration: const Duration(hours: 1), now: past);
    expect(s, isEmpty);
  });
}
